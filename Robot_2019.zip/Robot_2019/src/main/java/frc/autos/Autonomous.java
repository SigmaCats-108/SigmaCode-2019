package frc.autos;

//import frc.robot.Robot;

public class Autonomous {

    public void runAutonomous() {
        // Robot.follower.followPath();
        // Robot.drivetrain.sigmaDrive(0.3, 0.3);
    }
}